export class Lead {
    debtAmount?: number;
    debtCompanies?: string;
  }