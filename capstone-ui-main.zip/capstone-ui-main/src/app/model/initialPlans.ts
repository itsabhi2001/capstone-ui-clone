export class InitialPlans {
    offerList?: [lender: string, debt:number];
  }