export class InitialCheck {
    message?: string;
    code?: number;
  }