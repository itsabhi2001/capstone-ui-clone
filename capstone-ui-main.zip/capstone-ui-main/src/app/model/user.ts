export class User {
  id?: string;
  username?: string;
  password?: string;
  firstName?: string;
  lastName?: string;
  state?: string;
  dob?: string;
  offer?:JSON;
  role?: string;
}
